# Galaxy Kids Dynamic — Android prototype
Auteur : CONSCIENSUM CERCLE
Personnage : Mercier ZOKAZOUÏ

Fonctions :
- premier démarrage : prénom, classe, âge facultatif, langue et intérêt pour le turc ;
- profil sauvegardé localement ;
- accueil personnalisé ;
- une page dédiée par matière ;
- quiz dynamiques ;
- nouvelle question après une bonne réponse ;
- progression et étoiles ;
- difficulté qui augmente après plusieurs bonnes réponses ;
- retour à l'accueil.

Ouvrir le dossier dans Android Studio puis Build > Build APK(s).
