plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="org.consciensumcercle.galaxykids"; compileSdk=35
 defaultConfig { applicationId="org.consciensumcercle.galaxykids"; minSdk=24; targetSdk=35; versionCode=2; versionName="0.2.0" }
}
