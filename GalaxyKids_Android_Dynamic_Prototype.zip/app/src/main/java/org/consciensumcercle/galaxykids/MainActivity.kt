package org.consciensumcercle.galaxykids

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import kotlin.random.Random

data class Q(val text:String,val answers:List<String>,val correct:String,val explanation:String)

class MainActivity:Activity(){
    private val purple=Color.rgb(91,91,214); private val bg=Color.rgb(244,247,255)
    private lateinit var prefs:android.content.SharedPreferences
    private var name=""; private var level="CP1"; private var stars=0
    private var subject=""; private var streak=0

    private val bank=mapOf(
      "Mathématiques" to listOf(
        Q("Combien font 7 + 8 ?",listOf("14","15","16","17"),"15","7 + 8 = 15."),
        Q("Combien font 12 - 5 ?",listOf("5","6","7","8"),"7","12 - 5 = 7."),
        Q("Quel nombre est le plus grand ?",listOf("19","16","9","12"),"19","19 est le plus grand."),
        Q("Combien font 4 × 3 ?",listOf("7","12","14","16"),"12","4 groupes de 3 font 12.")
      ),
      "Français" to listOf(
        Q("Quel mot est correctement écrit ?",listOf("maison","maizon","meson","maîson"),"maison","La bonne orthographe est « maison »."),
        Q("Quel mot désigne un animal ?",listOf("table","chat","bleu","courir"),"chat","Un chat est un animal."),
        Q("Quel est le contraire de « grand » ?",listOf("haut","petit","long","fort"),"petit","Le contraire de grand est petit.")
      ),
      "Sciences" to listOf(
        Q("Quel organe sert principalement à respirer ?",listOf("Le cœur","Le poumon","L'estomac","Le cerveau"),"Le poumon","Les poumons participent à la respiration."),
        Q("Que faut-il faire avant de manger ?",listOf("Se laver les mains","Courir","Dormir","Jouer"),"Se laver les mains","Le lavage des mains aide à limiter les microbes.")
      ),
      "Civisme" to listOf(
        Q("À l'école, il faut…",listOf("Respecter les autres","Insulter","Tricher","Casser"),"Respecter les autres","Le respect facilite la vie collective.")
      ),
      "Histoire-Géographie" to listOf(
        Q("Dans quel pays se trouve Bangui ?",listOf("RCA","Sénégal","Kenya","Maroc"),"RCA","Bangui est la capitale de la République centrafricaine.")
      ),
      "Anglais" to listOf(
        Q("Comment dit-on « bonjour » en anglais ?",listOf("Goodbye","Hello","Thanks","Please"),"Hello","Hello signifie bonjour.")
      ),
      "Turc" to listOf(
        Q("Que signifie « Merhaba » ?",listOf("Bonjour","Merci","Au revoir","S'il vous plaît"),"Bonjour","Merhaba signifie bonjour."),
        Q("Comment dit-on « merci » en turc ?",listOf("Lütfen","Teşekkürler","Merhaba","Güle güle"),"Teşekkürler","Teşekkürler signifie merci."),
        Q("Que signifie « bir » ?",listOf("Deux","Trois","Un","Cinq"),"Un","Bir signifie un.")
      )
    )

    override fun onCreate(b:Bundle?){super.onCreate(b);prefs=getSharedPreferences("profile",Context.MODE_PRIVATE)
      if(!prefs.getBoolean("ready",false)) setup() else load(); home()
    }
    private fun load(){name=prefs.getString("name","Ami")?:"Ami";level=prefs.getString("level","CP1")?:"CP1";stars=prefs.getInt("stars",0)}
    private fun save(){prefs.edit().putBoolean("ready",true).putString("name",name).putString("level",level).putInt("stars",stars).apply()}
    private fun tv(s:String,size:Float,bold:Boolean=false):TextView{val t=TextView(this);t.text=s;t.textSize=size;t.setTextColor(Color.rgb(24,34,56));if(bold)t.setTypeface(null,1);t.setPadding(12,10,12,10);return t}
    private fun btn(s:String,a:()->Unit):Button{val b=Button(this);b.text=s;b.setOnClickListener{a()};return b}
    private fun card():LinearLayout{val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(18,16,18,16);val d=GradientDrawable();d.setColor(Color.WHITE);d.cornerRadius=26f;l.background=d;return l}
    private fun base():LinearLayout{val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(18,18,18,25);l.setBackgroundColor(bg);return l}

    private fun setup(){
      val scroll=ScrollView(this);val box=base();box.addView(tv("🌟 Galaxy Kids",30f,true))
      box.addView(tv("Bienvenue ! Faisons connaissance avec toi.",18f))
      val n=EditText(this);n.hint="Prénom de l'enfant";box.addView(n)
      box.addView(tv("🎒 Choisis ta classe",17f,true))
      val levels=arrayOf("CP1","CP2","CE1","CE2","CM1","CM2");var chosen="CP1"
      val group=RadioGroup(this);levels.forEach{v->val r=RadioButton(this);r.text=v;r.isChecked=v=="CP1";r.setOnClickListener{chosen=v};group.addView(r)};box.addView(group)
      val age=EditText(this);age.hint="Âge (facultatif)";age.inputType=2;box.addView(age)
      box.addView(tv("🌍 Langue principale",17f,true));box.addView(tv("Français / Sango — choix pédagogique à confirmer selon l'école.",13f))
      val turc=CheckBox(this);turc.text="🇹🇷 Je veux aussi apprendre le turc";box.addView(turc)
      box.addView(btn("🚀 Créer mon aventure"){if(n.text.toString().trim().isEmpty()){n.error="Entre le prénom";return@btn}
        name=n.text.toString().trim();level=chosen;stars=0;save();home()})
      scroll.addView(box);setContentView(scroll)
    }

    private fun home(){
      val scroll=ScrollView(this);val box=base()
      box.addView(tv("🌟 Galaxy Kids",28f,true));box.addView(tv("Bonjour $name ! 👋",23f,true))
      box.addView(tv("🤖 Mercier ZOKAZOUÏ : « Prêt(e) pour une nouvelle mission, $name ? »",16f))
      val h=card();h.setBackgroundColor(purple);val a=tv("🎮 Ton aventure\n$level  •  ⭐ $stars",23f,true);a.setTextColor(Color.WHITE);h.addView(a);box.addView(h)
      box.addView(tv("🗺️ Choisis une planète",21f,true))
      listOf("➗ Mathématiques","📖 Français","🔬 Sciences","🇨🇫 Civisme","🌍 Histoire-Géographie","🇬🇧 Anglais","🇹🇷 Turc").forEach{s->box.addView(btn(s){subjectPage(s.substringAfter(" "))})}
      box.addView(tv("💡 Chaque matière a sa propre page et ses propres défis.",13f))
      box.addView(btn("👤 Modifier le profil"){setup()})
      scroll.addView(box);setContentView(scroll)
    }

    private fun subjectPage(s:String){
      subject=s;val scroll=ScrollView(this);val box=base()
      box.addView(tv("🌍 $s",29f,true));box.addView(tv("Niveau : $level",15f))
      val c=card();c.addView(tv("🤖 Mercier ZOKAZOUÏ",19f,true));c.addView(tv("« Bienvenue dans $s, $name ! Ici, chaque bonne réponse te fait avancer. »",15f));c.addView(btn("🎮 Lancer le jeu"){game()});box.addView(c)
      box.addView(tv("🎯 Missions",20f,true))
      box.addView(tv("• Réussis 3 questions : +30 ⭐\n• Réussis 5 questions : badge de matière 🏅\n• Fais une série de bonnes réponses : bonus 🔥",15f))
      box.addView(btn("⬅️ Retour"){home()});scroll.addView(box);setContentView(scroll)
    }

    private fun game(){
      val qs=bank[subject]?:bank["Mathématiques"]!!;val q=qs[Random.nextInt(qs.size)]
      val box=base();box.addView(tv("🎮 $subject",27f,true));box.addView(tv("👤 $name  •  ⭐ $stars",14f))
      box.addView(tv("🤖 Mercier : « À toi ! »",16f))
      val c=card();c.addView(tv(q.text,21f,true))
      q.answers.shuffled().forEach{ans->c.addView(btn(ans){
        if(ans==q.correct){
          stars+=10;streak++;save()
          Toast.makeText(this,"🎉 Bravo $name ! +10 ⭐",Toast.LENGTH_SHORT).show()
          game()
        }else{
          streak=0;Toast.makeText(this,"💡 Pas encore. ${q.explanation}",Toast.LENGTH_LONG).show()
        }
      })}
      box.addView(c)
      box.addView(tv("🔥 Série actuelle : $streak",15f,true))
      box.addView(btn("⬅️ Quitter le jeu"){subjectPage(subject)})
      val scroll=ScrollView(this);scroll.addView(box);setContentView(scroll)
    }
}